import random

vzorci = [
    'Game of Thrones S&&&&E#### 720p HDTV x264-IMMERSE',
    'Game of Thrones S&&&&E#### HDTV XviD-FUM',
    'Game of Thrones S&&&&E####.HDTV x264-KiLLERS',
    'Game of Thrones S&&&&E#### 720p HBO WEBRip AAC2.0 x264-monkee',
    'Game of Thrones S&&&&E#### 720p HDTV x264-SVA',
    'Game of Thrones S&&&&E#### HDTV x264-FLEET',
    'Game.Of.Thrones.Season.&&&&.Ep.####.[720p]',
    'Game.Of.Thrones.Season.&&&&.Ep.####.[720p]',
    'Game.Of.Thrones.Season.&&&&.Ep.####.[720p]',
    'Game.Of.Thrones.Season.&&&&.Ep.####.[720p]',
    'Game.Of.Thrones.Season.&&&&.Ep.####.[720p]',
    'Game.Of.Thrones.Season.&&&&.Ep.####.[1080p]',
    'Game.Of.Thrones.Season.&&&&.Ep.####.[1080p]',
    'Game.Of.Thrones.Season.&&&&.Ep.####.[1080p]',
    'Game.Of.Thrones.Season.&&&&.Ep.####.[1080p]',
    'Game.Of.Thrones.Season.&&&&.Ep.####.[1080p]',
    'Game Of Thrones Season &&&& Ep #### [1080p]',
    'Game Of Thrones Season &&&& Ep #### [720p]',
    'Game Of Thrones Season &&&& Ep #### [720p]',
    'Game of Thrones.S&&&&E####.HDTV.x264-KiLLERS',
    'Game of Thrones.S&&&&E####.1080p.HDTV.x264-BATV',
    'Game of Thrones.S&&&&E####.720p.HBO.WEBRip.AAC2.0.x264-monkee',
    'Game.of.Thrones.S&&&&E####.720p.HDTV.x264-0SEC',
    'Game.of.Thrones.S&&&&E####.720p.HDTV.x264-IMMERSE',
    'Game.of.Thrones.S&&&&E####.720p.HDTV.x264-TOPKEK',
    'Game.of.Thrones.S&&&&E####.720p.HDTV.x264.AAC-Ozlem',
    'Game.of.Thrones.S&&&&E####.720p.HDTV.x265.6CH.HEVC-MRN',
    'Game.of.Thrones.S&&&&E####.720p.HDTV.x265.ShAaNiG',
    'Game.of.Thrones.S&&&&E####.HDTV.x264-KILLERS.HI',
    'Game.of.thrones.S&&&&E####.HDTV.XviD-AFG',
    'Game.of.Thrones.S&&&&E####.1080p.HDTV.x264-BATV.en',
    'Game.of.Thrones.S&&&&E####.720p.HDTV.x264-SVA',
    'Game.of.Thrones.S&&&&E####.HDTV.x264-FLEET',
    'Game.of.Thrones.S&&&&E####.INTERNAL.HDTV.x264-KILLERS',
]


def mogoce_nicla(n):
    return ('0' if random.random() > 0.5 and n < 10 else '') + str(n)


for sezona in range(1, 7):
    for epizoda in range(1, 11):
        ime_datoteke = random.choice(vzorci)
        ime_datoteke = ime_datoteke.replace('&&&&', mogoce_nicla(sezona))
        ime_datoteke = ime_datoteke.replace('####', mogoce_nicla(epizoda))
        if random.
        ime_datoteke += random.choice(['.mkv', '.avi', '.mp4'])
        print(ime_datoteke)

