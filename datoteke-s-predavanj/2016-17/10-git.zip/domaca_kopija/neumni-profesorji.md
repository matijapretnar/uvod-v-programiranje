# Komentarji o profesorjih


- prof. Maček: Kako je dolgočasen.
- doc. Pretnar: **Zakaj** točno nas sili uporabljati `git`?
