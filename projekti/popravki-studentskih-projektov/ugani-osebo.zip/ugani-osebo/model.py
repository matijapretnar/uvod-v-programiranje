import random
import json

ZACETEK = "Z"

ZMAGA = "W"

DATOTEKA_STANJE = "stanje.json"

# naredimo seznam oseb v katerem bodo slovarji z lastnostmi oseb
with open("osebe.json", "r", encoding="utf-8") as dat:
    osebe = json.load(dat)
vsi_mozni_atributi = {}
for oseba in osebe:
    for atribut, vrednost in oseba.items():
        if atribut not in vsi_mozni_atributi:
            vsi_mozni_atributi[atribut] = {vrednost}
        else:
            vsi_mozni_atributi[atribut].add(vrednost)

# stevila od 0 do 13 (vsaka za eno osebo), ki se bodo brisala iz polja,
#  ko bo oseba izpadla iz ugibanja
polje_oseb = []
for i in range(len(osebe)):
    polje_oseb.append(i)

polje_oseb1 = polje_oseb.copy()


class Igra:
    def __init__(
        self,
        oseba,
        kriterij=None,
        vrednost=None,
        stevilo_poskusov=0,
        ugibi=None,
    ):
        self.oseba = oseba
        self.kriterij = kriterij
        self.vrednost = vrednost
        self.stevilo_poskusov = stevilo_poskusov
        if ugibi is None:
            self.ugibi = []
        else:
            self.ugibi = ugibi

    def preostale_izbire_atributov(self):
        preostali = {}
        for atribut, lastnosti in vsi_mozni_atributi.items():
            mozne_lastnosti = set()
            for lastnost in lastnosti:
                if (atribut, lastnost) not in self.ugibi:
                    mozne_lastnosti.add(lastnost)
            if len(mozne_lastnosti) > 1:
                preostali[atribut] = mozne_lastnosti            
        return preostali

    @staticmethod
    def nova_nakljucna_igra():
        global polje_oseb
        polje_oseb = polje_oseb1.copy()
        nakljucna_oseba = random.choice(osebe)
        return Igra(nakljucna_oseba)

    def zmaga(self):
        return len(polje_oseb) == 1

    def povecaj_stevilo_poskusov(self):
        self.stevilo_poskusov += 1

    def ugibaj(self, kriterij, vrednost):
        global polje_oseb
        polje_oseb = polje_oseb.copy()
        pomozni = polje_oseb.copy()
        self.ugibi.append((kriterij, vrednost))
        if kriterij in self.oseba:
            self.povecaj_stevilo_poskusov()
            if vrednost == self.oseba[kriterij]:
                self.pravilnost = True
                for i in polje_oseb:
                    druga_oseba = osebe[i]
                    if vrednost != druga_oseba[kriterij]:
                        pomozni.remove(i)
            else:
                self.pravilnost = False
                for i in polje_oseb:
                    druga_oseba = osebe[i]
                    if vrednost == druga_oseba[kriterij]:
                        pomozni.remove(i)
            polje_oseb = pomozni.copy()
            if self.zmaga():
                return ZMAGA


class UganiOsebo:
    def __init__(self, datoteka_s_stanjem):
        self.datoteka_s_stanjem = datoteka_s_stanjem
        self.nalozi_igre_iz_datoteke()

    def prost_id_igre(self):
        if len(self.igre) == 0:
            return 0
        else:
            return max(self.igre.keys()) + 1

    def nova_igra(self):
        id_igre = self.prost_id_igre()
        igra = Igra.nova_nakljucna_igra()
        self.igre[id_igre] = (igra, ZACETEK)
        self.zapisi_igre_v_datoteko()
        return id_igre

    def ugibaj(self, id_igre, kriterij, vrednost):
        igra, _ = self.igre[id_igre]
        stanje = igra.ugibaj(kriterij, vrednost)
        self.igre[id_igre] = (igra, stanje)
        self.zapisi_igre_v_datoteko()

    def nalozi_igre_iz_datoteke(self):
        with open(self.datoteka_s_stanjem, "r", encoding="utf-8") as f:
            igre = json.load(f)
            self.igre = {
                int(id_igre): (Igra(oseba, ugibi), stanje)
                for id_igre, (oseba, ugibi, stanje) in igre.items()
            }

    def zapisi_igre_v_datoteko(self):
        with open(self.datoteka_s_stanjem, "w", encoding="utf-8") as f:
            igre = {
                id_igre: (igra.oseba, igra.ugibi, stanje)
                for id_igre, (igra, stanje) in self.igre.items()
            }
            json.dump(igre, f, ensure_ascii=False)
