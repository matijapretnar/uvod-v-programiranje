# UganiOsebo
## Opis programa

Inspiracija za program je znana družabna igra Ugani kdo (Guess who) pri kateri si vsak igralec izbere osebo, zmaga pa tisti, ki s vprašanji o lastnostih osebe prej ugotovi, katero osebo si je nasprotnik izbral.<br>
V tem primeru igrate proti računalniku, ki izbere osebo, vi pa jo želite uganiti v čim manj poskusih. <br>
Igro se igra v spletnem vmesniku, v okrnjeni verziji pa deluje tudi v tekstovnem vmesniku.
Pri izdelavi sem si pomagala s progamom Vislice, ki smo ga naredili na vajah.<br>

## Kako program zagnati?

Iz repozitorija si na svoj računalnik prenesite zip datoteko.<br>
Odprite jih v izbranem urejevalniku<br>
Poženite datoteko spletni_vmesnik.py<br>
Kliknite na povezavo http://localhost:8080/<br>
Odprla se vam bo spletna stran z igro, kjer so napisana navodila za igranje<br>

## Izgled

Stran sem oblikovala sama, slike oseb in slika za ozadje pa niso moja last.<br>
ozadje: https://sv.vecteezy.com/vektor-konst/690856-rosa-blom-ram-pa-en-vit-bakgrund (28. 7. 2020)<br>
osebe: https://lh3.googleusercontent.com/07KAHqdPqMps67C2KdyP1qA1TpsYgMOyf65C_QvPTyTUMuug6p1U734UKVdUSFd9SOJCxQ=s113 (28. 7. 2020)

